# CDS Homework 5 Package

The authors of this library: 

* Diego Eslava
* Kallioppé Stassinos
* Simón Caicedo

This library contains all the functions necessary to perform the data analysis for exercise 6 of the homework 5 for Computing for Data Science Course at Barcelona School of Economics. 


