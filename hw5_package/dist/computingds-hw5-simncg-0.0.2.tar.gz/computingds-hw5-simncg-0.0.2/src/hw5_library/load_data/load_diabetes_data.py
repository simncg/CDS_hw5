# Function
import pandas as pd

def read_data_diabetes():
    return pd.read_csv("sample_diabetes_mellitus_data.csv")